/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.sauces.examen2;

import java.util.Set;
import java.util.Map;
import java.util.List;

public class Operadora {
    private String nombre;
    private Set<Tarifa> tarifas;
    private Map<String,LineaMovil> lineas;

    
    // COMPLETA EL CÓDIGO
    public Operadora(String nombre) {
        this.nombre = nombre;
    }
    
    public String getNombre() {
        return nombre;
    }

    // COMPLETA EL CÓDIGO
    public List<Tarifa> getTarifas() {
        return null;
    }

    // COMPLETA EL CÓDIGO
    public void setTarifas(List<Tarifa> tarifas) {
        
    }

    // COMPLETA EL CÓDIGO
    public List<LineaMovil> getLineas() {
        return null;
    }

    // COMPLETA EL CÓDIGO
    public void setLineas(List<LineaMovil> lineas) {
      
    }
    
    // COMPLETA EL CÓDIGO
    public boolean agregarTarifa(Tarifa tarifa){
        return false;
    }
    
    // COMPLETA EL CÓDIGO
    public Tarifa getTarifa(String nombre){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public boolean agregarLineaMovil(LineaMovil linea){
        return false;
    }
    
    // COMPLETA EL CÓDIGO
    public LineaMovil getLineaMovil(String numero){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public boolean cancelarLineaMovil(String numero){
        return false;
    }
}
