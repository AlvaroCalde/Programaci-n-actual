/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.sauces.examen2;

import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;


// COMPLETA EL CÓDIGO
public class LineaMovil {
    private final String numero;
    private String cliente;
    private Tarifa tarifa;
    private int datosDisponibles;
    private List<Consumo> consumos;

    
    // COMPLETA EL CÓDIGO
    public LineaMovil(String numero, String cliente, Tarifa tarifa) {
        this.numero = numero;
        this.cliente = cliente;
        this.tarifa = tarifa;
    }

    public String getNumero() {
        return numero;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Tarifa getTarifa() {
        return tarifa;
    }

    public void setTarifa(Tarifa tarifa) {
        this.tarifa = tarifa;
    }

    public int getDatosDisponibles() {
        return datosDisponibles;
    }

    public void setDatosDisponibles(int datosDisponibles) {
        this.datosDisponibles = datosDisponibles;
    }

    public List<Consumo> getConsumos() {
        return consumos;
    }

    public void setConsumos(List<Consumo> consumos) {
        this.consumos = consumos;
    }
    
    // COMPLETA EL CÓDIGO
    public float registrarLlamada(LocalDate fecha, LocalTime hora, String numero, int duracion){
        return 0;
    }
    
    // COMPLETA EL CÓDIGO
    public float registrarSms(LocalDate fecha, LocalTime hora, String numero){
        return 0;
    }
    
    // COMPLETA EL CÓDIGO
    public int registrarConsumoDatos(LocalDate fecha, LocalTime hora, int volumen){
        return 0;
    }
    
    // COMPLETA EL CÓDIGO
    public List<Consumo> listarConsumos(TipoConsumo tipoConsumo){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public List<Consumo> listarConsumos(LocalDate desde, LocalDate hasta){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public String getConsumo(TipoConsumo tipoConsumo){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public Consumo getConsumoMayorImporte(){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public Llamada getLLamadaMayorDuracion(){
        return null;
    }
    
    // COMPLETA EL CÓDIGO
    public int cargarConsumos(String archivo){
        return 0;
    }
    
    // COMPLETA EL CÓDIGO
    public int guardarConsumos(String archivo){
        return 0;
    }
}
